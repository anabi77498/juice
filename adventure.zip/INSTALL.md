# Installation

1. Clone this repository

2. Navigate to the root directory via terminal

3. Ensure that all data (in JSON format) is stored in /data directory

4. Run `make juice` to access the application
